package com.ssafy.book.model.dao;

import java.util.HashMap;

import com.ssafy.book.model.dto.Member;

public interface MemberDAO {

	// 회원가입
	public void signUp(Member member);
	
	// 아이디 중복 체크
	public int idCheck(String userId);
	
	// 로그인
	public Member doLogin(HashMap<String, String> memberInfo);
	
	// 회원정보 조회
	public Member memberInfo(int userNo);
	
	// 회원정보 수정
	public void updateInfo(Member member);
	
	// 회원 탈퇴
	public void deleteInfo(int userNo);
	
}
