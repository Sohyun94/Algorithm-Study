package com.ssafy.book.service;

import java.util.HashMap;

import com.ssafy.book.config.MyAppSqlConfig;
import com.ssafy.book.model.dao.MemberDAO;
import com.ssafy.book.model.dto.Member;

public class MemberServiceImpl implements MemberService {

	private MemberDAO memberDAO;
	private static MemberService instance;

	private MemberServiceImpl() {
		memberDAO = MyAppSqlConfig.getSession().getMapper(MemberDAO.class);
	}

	public static MemberService getInstance() {
		if (instance == null) {
			instance = new MemberServiceImpl();
		}

		return instance;
	}

	// 회원가입
	@Override
	public boolean signUp(Member member) {
		boolean isSigned = false;

		// 아이디 중복 체크
		int idCheck = memberDAO.idCheck(member.getUserId());

		if (idCheck == 0) {
			memberDAO.signUp(member);
			isSigned = true;
		}

		return isSigned;

	}

	// 로그인
	@Override
	public Member doLogin(String userId, String userPwd) {

		HashMap<String, String> memberInfo = new HashMap<>();

		memberInfo.put("userId", userId);
		memberInfo.put("userPwd", userPwd);

		Member member = memberDAO.doLogin(memberInfo);

		return member;

	}

	// 회원정보 조회
	@Override
	public Member memberInfo(int userNo) {
		Member member = memberDAO.memberInfo(userNo);
		return member;
	}

	// 회원정보 수정
	@Override
	public void updateInfo(Member member) {
		memberDAO.updateInfo(member);
	}

	// 회원 탈퇴
	@Override
	public void deleteInfo(int userNo) {
		memberDAO.deleteInfo(userNo);
	}

}
