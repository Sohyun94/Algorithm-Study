package com.ssafy.book.service;

import java.util.List;

import com.ssafy.book.model.dto.Book;

public interface BookService {

	// 책 정보 전체 조회
	public List<Book> selectAllBook();
	
	// 책 정보 상세 조회
	public Book selectOneBook(int bookNo);
	
}
