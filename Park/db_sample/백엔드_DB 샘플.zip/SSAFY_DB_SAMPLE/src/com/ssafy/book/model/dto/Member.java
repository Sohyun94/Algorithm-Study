package com.ssafy.book.model.dto;

import java.util.Date;

public class Member {

	// 회원 객체에 저장되는 속성들
	private int userNo;
	private String userId;
	private String userPwd;
	private String userName;
	private String userEmail;
	private String address;
	private String phoneNumber;
	private Date jointDate;

	// 생성자
	// 기본
	public Member() {

	}

	// 조건(회원가입 시 입력되는 정보만 저장)
	public Member(String userId, String userPwd, String userName, String userEmail, String address,
			String phoneNumber) {
		this.userId = userId;
		this.userPwd = userPwd;
		this.userName = userName;
		this.userEmail = userEmail;
		this.address = address;
		this.phoneNumber = phoneNumber;
	}

	// 설정자 및 조회자
	public int getUserNo() {
		return userNo;
	}

	public void setUserNo(int userNo) {
		this.userNo = userNo;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Date getJointDate() {
		return jointDate;
	}

	public void setJointDate(Date jointDate) {
		this.jointDate = jointDate;
	}

}
