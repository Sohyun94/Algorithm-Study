package com.ssafy.book.model.dao;

import java.util.HashMap;
import java.util.List;

import com.ssafy.book.model.dto.Book;

public interface OrderDAO {

	// 주문하기
	public void insertOrder(HashMap<String, Integer> orderInfo);
	
	// 주문 취소하기
	public void deleteOrder(HashMap<String, Integer> orderInfo);
	
	// 장바구니에 담기
	public void insertPick(HashMap<String, Integer> pickInfo);
	
	// 장바구니에서 제거하기
	public void deletePick(HashMap<String, Integer> pickInfo);
	
	// 주문 조회
	public List<HashMap<String, String>> selectOrder(int userNo);
	
	// 장바구니 조회
	public List<Book> selectPick(int userNo);
	
}
