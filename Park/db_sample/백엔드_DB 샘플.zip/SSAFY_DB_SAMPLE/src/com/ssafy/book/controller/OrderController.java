package com.ssafy.book.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.book.model.dto.Member;
import com.ssafy.book.service.OrderService;
import com.ssafy.book.service.OrderServiceImpl;

@WebServlet("/order")
public class OrderController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private OrderService orderService = OrderServiceImpl.getInstance();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doHandle(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		doHandle(request, response);
	}

	private void doHandle(HttpServletRequest request, HttpServletResponse response) throws IOException {

		String act = request.getParameter("act");
		HttpSession session = request.getSession();
		Member member = (Member) session.getAttribute("loginUser");
		
		int bookNo;
		int userNo = member.getUserNo();
		
		switch (act) {
		case "doOrder":
			bookNo = Integer.parseInt(request.getParameter("bookNo"));
			orderService.doOrder(userNo, bookNo);
			
			response.sendRedirect("book?act=list");
			
			break;
		case "doPick":
			bookNo = Integer.parseInt(request.getParameter("bookNo"));
			orderService.doPick(userNo, bookNo);
			
			response.sendRedirect("book?act=list");
			break;
		case "deletePick":
			bookNo = Integer.parseInt(request.getParameter("bookNo"));
			orderService.deletePick(userNo, bookNo);
			
			response.sendRedirect("member?act=myPage");
			break;
		case "deleteOrder":
			int orderNo = Integer.parseInt(request.getParameter("orderNo"));
			
			orderService.deleteOrder(userNo, orderNo);
			
			response.sendRedirect("member?act=myPage");
			break;
		}

	}

}
