package com.ssafy.book.model.dao;

import java.util.List;

import com.ssafy.book.model.dto.Book;

public interface BookDAO {

	// 책 전체 조회
	public List<Book> selectAllBook();

	// 책 상세 조회
	public Book selectOneBook(int bookNo);

}
