package com.ssafy.book.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.book.model.dto.Book;
import com.ssafy.book.model.dto.Member;
import com.ssafy.book.service.MemberService;
import com.ssafy.book.service.MemberServiceImpl;
import com.ssafy.book.service.OrderService;
import com.ssafy.book.service.OrderServiceImpl;

@WebServlet("/member")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private MemberService memberService = MemberServiceImpl.getInstance();
	private OrderService orderService = OrderServiceImpl.getInstance();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doHandle(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		doHandle(request, response);
	}

	private void doHandle(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		String act = request.getParameter("act");

		String userId;
		String userPwd;
		String userName;
		String userEmail;
		String address;
		String phoneNumber;
		
		Member member;
		
		HttpSession session = request.getSession();

		switch (act) {
		case "login":
			if (request.getMethod().equals("POST")) {
				userId = request.getParameter("userId");
				userPwd = request.getParameter("userPwd");

				member = memberService.doLogin(userId, userPwd);

				if (member != null) {
					session.setAttribute("loginUser", member);
					response.sendRedirect("book?act=list");
				} else {
					request.setAttribute("userId", userId);
					request.setAttribute("userPwd", userPwd);
					request.setAttribute("message", "아이디 또는 비밀번호가 잘못 입력되었습니다.");

					request.getRequestDispatcher("./views/member/login.jsp").forward(request, response);
				}
			}
			break;
		case "signUp":
			if (request.getMethod().equals("POST")) {
				userId = request.getParameter("userId");
				userPwd = request.getParameter("userPwd");
				userName = request.getParameter("userName");
				userEmail = request.getParameter("userEmail");
				address = request.getParameter("address");
				phoneNumber = request.getParameter("phoneNumber");

				member = new Member(userId, userPwd, userName, userEmail, address, phoneNumber);

				boolean isSigned = memberService.signUp(member);

				if (isSigned) {
					response.sendRedirect("./views/member/login.jsp");
				} else {
					request.setAttribute("message", "이미 존재하는 계정입니다.");
					request.getRequestDispatcher("./views/member/signUp.jsp").forward(request, response);
				}
			}
			break;
		case "logout":
			session.invalidate();

			response.sendRedirect("book?act=list");

			break;
		case "myPage":

			Member loginUser = (Member) session.getAttribute("loginUser");	
			member = memberService.memberInfo(loginUser.getUserNo());
			request.setAttribute("member", member);

			List<Book> pickList = orderService.selectPick(member.getUserNo());
			request.setAttribute("pickList", pickList);

			List<HashMap<String, String>> orderList = orderService.selectOrder(member.getUserNo());
			request.setAttribute("orderList", orderList);

			request.getRequestDispatcher("./views/member/myPage.jsp").forward(request, response);

			break;
		case "updateInfo":
			userId = request.getParameter("userId");
			userPwd = request.getParameter("userPwd");
			userName = request.getParameter("userName");
			userEmail = request.getParameter("userEmail");
			address = request.getParameter("address");
			phoneNumber = request.getParameter("phoneNumber");
			
			member = new Member(userId, userPwd, userName, userEmail, address, phoneNumber);
			
			memberService.updateInfo(member);
			
			response.sendRedirect("member?act=myPage");
			
			break;
		}

	}

}
