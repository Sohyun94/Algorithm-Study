package com.ssafy.book.service;

import com.ssafy.book.model.dto.Member;

public interface MemberService {

	// 회원가입
	public boolean signUp(Member member);
	
	// 로그인
	public Member doLogin(String userId, String userPwd);
	
	// 회원정보 조회
	public Member memberInfo(int userNo);
	
	// 회원정보 수정
	public void updateInfo(Member member);
	
}
