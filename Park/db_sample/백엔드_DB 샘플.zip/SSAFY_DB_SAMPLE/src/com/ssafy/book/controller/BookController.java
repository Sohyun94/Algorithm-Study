package com.ssafy.book.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.book.model.dto.Book;
import com.ssafy.book.service.BookService;
import com.ssafy.book.service.BookServiceImpl;

@WebServlet("/book")
public class BookController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private BookService bookService = BookServiceImpl.getInstance();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doHandle(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		doHandle(request, response);
	}

	private void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String act = request.getParameter("act");

		switch (act) {
		// 책 전체 조회
		case "list":
			// 책 정보를 bookList에 저장
			List<Book> bookList = bookService.selectAllBook();
			
			// bookList를 request 객체에 담기
			request.setAttribute("bookList", bookList);
			// list.jsp로 이동
			request.getRequestDispatcher("/views/book/list.jsp").forward(request, response);

			break;
			
		// 주문 페이지로 이동
		case "info":
			// 요청에 포함된 책 번호 불러오기
			int bookNo = Integer.parseInt(request.getParameter("bookNo"));
			// 요청에 포함된 책 번호에 해당하는 book 객체 저장
			Book book = bookService.selectOneBook(bookNo);
			
			// book 객체를 request 객체에 담기
			request.setAttribute("book", book);
			// order.jsp로 이동
			request.getRequestDispatcher("/views/order/order.jsp").forward(request, response);
			break;
		}
	}

}
