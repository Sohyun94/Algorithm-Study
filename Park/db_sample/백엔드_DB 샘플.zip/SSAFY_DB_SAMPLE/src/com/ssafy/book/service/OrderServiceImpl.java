package com.ssafy.book.service;

import java.util.HashMap;
import java.util.List;

import com.ssafy.book.config.MyAppSqlConfig;
import com.ssafy.book.model.dao.OrderDAO;
import com.ssafy.book.model.dto.Book;

public class OrderServiceImpl implements OrderService {

	private static OrderService instance;
	private OrderDAO orderDAO;

	private OrderServiceImpl() {
		orderDAO = MyAppSqlConfig.getSession().getMapper(OrderDAO.class);
	}

	public static OrderService getInstance() {
		if (instance == null) {
			instance = new OrderServiceImpl();
		}

		return instance;
	}

	// 주문하기
	@Override
	public void doOrder(int userNo, int bookNo) {
		HashMap<String, Integer> orderInfo = new HashMap<>();

		orderInfo.put("userNo", userNo);
		orderInfo.put("bookNo", bookNo);

		orderDAO.insertOrder(orderInfo);

	}

	@Override
	public void deleteOrder(int userNo, int orderNo) {
		HashMap<String, Integer> orderInfo = new HashMap<>();
		
		orderInfo.put("userNo", userNo);
		orderInfo.put("orderNo", orderNo);
		
		orderDAO.deleteOrder(orderInfo);

	}

	// 장바구니에 담기
	@Override
	public void doPick(int userNo, int bookNo) {
		HashMap<String, Integer> pickInfo = new HashMap<>();

		pickInfo.put("userNo", userNo);
		pickInfo.put("bookNo", bookNo);

		List<Book> pickList = orderDAO.selectPick(userNo);

		for (int i = 0; i < pickList.size(); i++) {
			if (pickList.get(i).getBookNo() == bookNo) {
				return;
			}
		}

		orderDAO.insertPick(pickInfo);

	}

	// 장바구니에서 제거
	@Override
	public void deletePick(int userNo, int bookNo) {
		HashMap<String, Integer> pickInfo = new HashMap<>();

		pickInfo.put("userNo", userNo);
		pickInfo.put("bookNo", bookNo);
		
		orderDAO.deletePick(pickInfo);

	}

	@Override
	public List<HashMap<String, String>> selectOrder(int userNo) {
		List<HashMap<String, String>> orderList = orderDAO.selectOrder(userNo);
		return orderList;
	}

	// 장바구니 조회
	@Override
	public List<Book> selectPick(int userNo) {
		List<Book> pickList = orderDAO.selectPick(userNo);
		return pickList;
	}

}
