package com.ssafy.book.service;

import java.util.HashMap;
import java.util.List;

import com.ssafy.book.model.dto.Book;

public interface OrderService {

	// 주문
	public void doOrder(int userNo, int bookNo);

	// 주문 취소하기
	public void deleteOrder(int userNo, int orderNo);

	// 장바구니 추가
	public void doPick(int userNo, int bookNo);

	// 장바구니에서 제거하기
	public void deletePick(int userNo, int bookNo);

	// 주문 목록 조회
	public List<HashMap<String, String>> selectOrder(int userNo);

	// 장바구니 목록 조회
	public List<Book> selectPick(int userNo);

}
