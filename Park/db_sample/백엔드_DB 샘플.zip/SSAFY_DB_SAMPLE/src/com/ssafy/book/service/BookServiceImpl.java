package com.ssafy.book.service;

import java.util.List;

import com.ssafy.book.config.MyAppSqlConfig;
import com.ssafy.book.model.dao.BookDAO;
import com.ssafy.book.model.dto.Book;

public class BookServiceImpl implements BookService {

	// singleton
	private static BookServiceImpl instance;

	// BookDAO 연결
	private BookDAO bookDAO;

	private BookServiceImpl() {
		bookDAO = MyAppSqlConfig.getSession().getMapper(BookDAO.class);
	}

	public static BookService getInstance() {
		if (instance == null) {
			instance = new BookServiceImpl();
		}

		return instance;
	}

	// 책 전체 조회
	@Override
	public List<Book> selectAllBook() {
		List<Book> bookList = bookDAO.selectAllBook();
		return bookList;
	}

	// 책 상세 조회
	@Override
	public Book selectOneBook(int bookNo) {
		Book book = bookDAO.selectOneBook(bookNo);
		return book;
	}

}
