package com.ssafy.book.model.dto;

public class Book {

	// 책 정보에 포함된 속성
	private int bookNo; // 책 고유 번호
	private String bookName; // 책 제목
	private int price; // 책 가격
	private String publisher; // 출판사

	// 설정자 및 조회자
	public int getBookNo() {
		return bookNo;
	}

	public void setBookNo(int bookNo) {
		this.bookNo = bookNo;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

}
