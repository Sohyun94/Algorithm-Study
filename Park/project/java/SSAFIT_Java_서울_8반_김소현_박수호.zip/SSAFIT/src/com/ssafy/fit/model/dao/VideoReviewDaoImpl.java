package com.ssafy.fit.model.dao;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.ssafy.fit.model.VideoReview;

public class VideoReviewDaoImpl implements IVideoReviewDao {
	
	private Map<Integer, List<VideoReview>> videoReviewDb = new HashMap<>();
	private static int reviewNo;
	private static VideoReviewDaoImpl instance = new VideoReviewDaoImpl();

	// 싱글턴 패턴
	private VideoReviewDaoImpl() {
	}

	public static VideoReviewDaoImpl getInstance() {
		return instance;
	}

	// 리뷰 등록
	@Override
	public int insertReview(VideoReview videoReview) throws IOException {

		// 파일 쓰기
		BufferedWriter bw = new BufferedWriter(
				new OutputStreamWriter(new FileOutputStream("data/review.json"), "utf-8"));

		// 리뷰 번호가 이어지도록 설정
		reviewNo = videoReviewDb.size() + 1;

		// 정해진 리뷰 번호 입력
		videoReview.setReviewNo(reviewNo);

		// list 객체 생성
		List<VideoReview> list = new ArrayList<>();
		
		// list 객체에 전달받은 리뷰 객체 입력
		list.add(videoReview);

		// 리뷰 객체가 담긴 list를 데이터 베이스에 추가
		videoReviewDb.put(reviewNo, list);

		// Gson 객체 생성
		Gson gson = new Gson();

		// 데이터 베이스 내용을 json으로 변환
		String jsonStr = gson.toJson(videoReviewDb);

		// json 내용을 파일에 작성
		bw.write(jsonStr);

		// 종료
		bw.flush();
		bw.close();

		return videoReview.getReviewNo();
	}

	// 리뷰 목록 조회
	@Override
	public List<VideoReview> selectReview(int videoNo) {

		try {

			// json 파일 읽기
			JsonReader jsonFile = new JsonReader(new FileReader("data/review.json"));

			// Map 타입 생성
			Type mapTokenType = new TypeToken<Map<Integer, List<VideoReview>>>() {
			}.getType();

			// 파일 내용을 Map 타입으로 변환
			Map<Integer, List<VideoReview>> map = new Gson().fromJson(jsonFile, mapTokenType);

			// 변환된 Map을 데이터베이스에 적용
			videoReviewDb = map;

			// list 객체 생성
			List<VideoReview> list = new ArrayList<>();

			// 전달받은 비디오 번호에 대한 정보를 데이터 베이스에서 list 객체로 복사하는 반복문
			for (int i = 1; i <= videoReviewDb.size(); i++) {
				if (videoReviewDb.get(i).get(0).getVideoNo() == videoNo) {
					list.add(videoReviewDb.get(i).get(0));
				}
			}

			// 복사된 리스트 반환
			return list;
			
		} catch (FileNotFoundException e) {
			
			// 에러 메시지 출력
			String errorMsg = e.getMessage();
			System.out.println(errorMsg);
			
		}
		
		return null;

	}

}
