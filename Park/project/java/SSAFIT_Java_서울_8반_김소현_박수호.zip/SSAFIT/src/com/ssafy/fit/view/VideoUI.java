package com.ssafy.fit.view;

import java.awt.Desktop;
import java.net.URI;
import java.util.List;
import java.util.Scanner;

import com.ssafy.fit.model.Video;
import com.ssafy.fit.model.dao.IVideoDao;
import com.ssafy.fit.model.dao.VideoDaoImpl;;

public class VideoUI {
	private static Scanner sc = new Scanner(System.in);
	private static VideoUI instance = new VideoUI();

	public static VideoUI getInstance() {
		return instance;
	}

	private VideoUI() {
	}

	private IVideoDao videoDao = VideoDaoImpl.getInstance();

	// 영상 목록 UI
	public void service() {
		while (true) {
			System.out.println("--------------------");
			System.out.println("1. 영상목록");
			System.out.println("0. 이전으로");
			System.out.println("--------------------");
			System.out.print("메뉴를 선택하세요 : ");
			int sel = sc.nextInt();
			switch (sel) {
			case 1:
				listVideo();
				break;
			case 0:
				return;
			default:
				System.out.println("입력이 잘못되었습니다.");
			}
		}
	}

	// 영상 목록 조회
	private void listVideo() {
		try {
			while (true) {
				List<Video> list = videoDao.selectVideo(); // 데이터 베이스에서 영상 목록 조회
				System.out.println("--------------------");
				System.out.printf("전체 %d개%n", list.size());
				System.out.println("--------------------");
				for (Video v : list) {
					System.out.printf("%2d %4s %s %n", v.getNo(), v.getPart(), v.getTitle());
				}

				System.out.println("--------------------");
				System.out.println("1. 영상상세");
				System.out.println("2. 영상보기");
				System.out.println("0. 이전으로");
				System.out.println("--------------------");
				System.out.print("메뉴를 선택하세요 : ");
				int sel = sc.nextInt();
				switch (sel) {
				case 1:
					detailVideo();
					break;
				case 2:
					System.out.print("영상번호를 입력하세요 : ");
					int no = sc.nextInt();
					Video v = videoDao.selectVideoByNo(no);
					Desktop.getDesktop().browse(new URI(v.getUrl()));
					break;
				case 0:
					return;
				default:
					System.out.println("입력이 잘못되었습니다.");
				}
			}
		} catch (Exception e) {
			System.out.println("영상 조회 문제가 발생했습니다.");
		}
	}

	// 영상 정보 상세보기 화면
	private void detailVideo() {
		try {
			
			System.out.print("영상번호를 입력하세요 : ");
			int no = sc.nextInt();
			
			Video video = videoDao.selectVideoByNo(no); // 입력한 번호에 대한 영상정보 객체에 저장
			
			System.out.println(video);
			System.out.println("--------------------");
			System.out.println("번호 : " + video.getNo());
			System.out.println("제목 : " + video.getTitle());
			System.out.println("운동 : " + video.getPart());
			System.out.println("영상URL : " + video.getUrl());
			System.out.println("--------------------");
			
			VideoReviewUi.getInstance(no).service(); // 리뷰 화면으로 이동
			
		} catch (Exception e) {
			
			// 에러 메시지 출력
			System.out.println("영상 조회시 문제가 발생했습니다.");
		}

	}

}
