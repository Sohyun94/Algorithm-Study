package com.ssafy.fit.model.dao;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;

import com.google.gson.Gson;
import com.ssafy.fit.exception.VideoNotFoundException;
import com.ssafy.fit.model.Video;

public class VideoDaoImpl implements IVideoDao {

	// singlton
	private static VideoDaoImpl instance = new VideoDaoImpl();

	public static VideoDaoImpl getInstance() {

		return instance;
	}

	private VideoDaoImpl() {

	}

	// 비디오 목록 조회
	@Override
	public List<Video> selectVideo() {

		StringBuilder sb = new StringBuilder();
		
		try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("data/video.json")))) {
			
			String str = null;
			
			// 파일 읽기
			while ((str = br.readLine()) != null) {
				sb.append(str).append("\n");
			}
			
			// 파일 내용
			String jsonStr = sb.toString();
			
			// Gson 객체 생성
			Gson gson = new Gson();
			
			// 파일 내용을 Video 타입의 배열로 변환
			Video[] videos = gson.fromJson(jsonStr, Video[].class);
			
			// 배열을 List로 변환한 후 반환
			return Arrays.asList(videos);
			
		} catch (FileNotFoundException e) {
			
			// 에러 메시지 출력
			String errorMsg = e.getMessage();
			System.out.println(errorMsg);
			
		} catch (IOException e) {
			
			// 에러 메시지 출력
			System.out.println("파일을 찾을 수 없습니다.");
		}
		return null;
	}

	// 영상 상세조회
	@Override
	public Video selectVideoByNo(int no) throws VideoNotFoundException {
		
		// 영상 목록
		List<Video> list = this.selectVideo();
		
		// 영상 목록 중 전달받은 번호에 해당하는 영상정보 반환
		for (Video v : list) {
			if (v.getNo() == no)
				return v;
		}
		
		// 영상 정보가 없으면 예외 처리
		throw new VideoNotFoundException(no);
	}

}
