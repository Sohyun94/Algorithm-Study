package com.ssafy.fit;

import com.ssafy.fit.view.MainUI;

public class App {
	public static void main(String[] args) {
		
		//시작 메시지
		System.out.println("SSAFIT Application 시작");
		
		// 메인 화면
		MainUI.getInstance().service();
	}
}
