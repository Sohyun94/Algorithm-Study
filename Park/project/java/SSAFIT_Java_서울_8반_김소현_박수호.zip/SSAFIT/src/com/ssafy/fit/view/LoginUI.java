package com.ssafy.fit.view;

import java.util.Scanner;

import com.ssafy.fit.model.dao.IUserManager;
import com.ssafy.fit.model.dao.UserManagerImpl;

public class LoginUI {
	private static Scanner sc = new Scanner(System.in);
	private static LoginUI instance = new LoginUI();

	private IUserManager userDao = UserManagerImpl.getInstance();

	public static LoginUI getInstance() {
		return instance;
	}

	private LoginUI() {
	}

	// 로그인 메뉴 선택시 출력될 UI
	public void service() {
		System.out.println("--------------------");
		System.out.println("자바로 구현하는 SSAFIT");
		System.out.println("--------------------");
		while (true) {
			System.out.println("--------------------");
			System.out.println("1. 로그인");
			System.out.println("2. 회원가입");
			System.out.println("0. 이전으로");
			System.out.println("--------------------");
			System.out.print("메뉴를 선택하세요 : ");
			int sel = sc.nextInt();
			switch (sel) {
			case 1:
				login();
				break;
			case 2:
				SignUI.getInstance().service();
			case 0:
				return;
			default:
				System.out.println("입력이 잘못되었습니다.");
			}
		}
	}

	private void login() {

		String id;
		String pwd;

		// 아이디 입력
		// 아이디 중복 검사(유효성 검증)
		while (true) {

			System.out.print("아이디를 입력하세요. : ");
			id = sc.next();

			if (userDao.searchId(id)) {
				break;
			} else {
				System.out.println("존재하지 않는 아이디입니다.");
				System.out.println("다시 입력하세요.");
			}

		}

		// 비밀번호 검사
		// 비밀번호가 일치해야 로그인 성공
		while (true) {

			System.out.print("비밀번호를 입력하세요. : ");
			pwd = sc.next();

			if (userDao.login(id, pwd)) {
				System.out.println("로그인 되었습니다.");
				MainUI.getInstance().service();
			} else {
				System.out.println("비밀번호가 일치하지 않습니다.");
				System.out.println("다시 입력하세요. ");
			}

		}

	}

}
