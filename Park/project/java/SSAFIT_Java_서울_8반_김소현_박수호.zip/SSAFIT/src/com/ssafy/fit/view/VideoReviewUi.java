package com.ssafy.fit.view;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import com.ssafy.fit.model.VideoReview;
import com.ssafy.fit.model.dao.IUserManager;
import com.ssafy.fit.model.dao.IVideoReviewDao;
import com.ssafy.fit.model.dao.UserManagerImpl;
import com.ssafy.fit.model.dao.VideoReviewDaoImpl;

public class VideoReviewUi {
	private static Scanner sc = new Scanner(System.in);

	private static VideoReviewUi instance;

	private IVideoReviewDao videoReviewDao = VideoReviewDaoImpl.getInstance();
	private static IUserManager userDao = UserManagerImpl.getInstance();
	private int videoNo;

	private VideoReviewUi(int videoNo) {
		this.videoNo = videoNo;
	}

	public static VideoReviewUi getInstance(int videoNo) {
		instance = new VideoReviewUi(videoNo);

		return instance;
	}

	// 영상 리뷰 정보 UI
	public void service() {
		while (true) {
			listReview();
			if (userDao.isLogin()) {
				System.out.println("1. 리뷰등록"); // 로그인해야 리뷰 등록 가능
			}
			System.out.println("0. 이전으로");
			System.out.println("--------------------");
			System.out.print("메뉴를 선택하세요 : ");
			int sel = sc.nextInt();
			switch (sel) {
			case 1:
				// 로그인해야 리뷰 등록 가능
				if (userDao.isLogin()) {
					registReview();
					break;
				} else {
					System.out.println("잘못 입력하셨습니다.");
					continue;
				}
			case 0:
				return;
			default:
				System.out.println("입력이 잘못되었습니다.");
			}
		}
	}

	// 리뷰 목록 조회
	private void listReview() {
		
		try {
			// 전달한 번호에 대한 리뷰 정보 전달받아 list에 입력
			List<VideoReview> list = videoReviewDao.selectReview(videoNo);
			
			if (list == null) {
				list = Collections.emptyList();
			}
			
			System.out.println("--------------------");
			System.out.printf("영상리뷰 : %d개%n", list.size());
			System.out.println("--------------------");
			
			// 전달된 리뷰 정보 출력
			if (!list.isEmpty()) {
				for (VideoReview v : list)
					System.out.printf("%2d %4s %s %n", v.getReviewNo(), v.getNickName(), v.getContent());
				System.out.println("--------------------");
			}
			
		} catch (Exception e) {
			
			// 에러 메시지 출력
			e.printStackTrace();
			System.out.println("리뷰 조회시 문제가 발생했습니다.");
		}
	}

	private void registReview() {
		
		// VideoReview 객체 생성
		VideoReview vr = new VideoReview();
		
		// 전달받은 비디오 번호 입력
		vr.setVideoNo(videoNo);
		
		// 전달받은 닉네임 입력
		System.out.print("닉네임을 입력하세요 : ");
		vr.setNickName(sc.next());
		
		// 전달받은 내용 입력
		System.out.print("내용을 입력하세요 : ");
		vr.setContent(sc.next());
		
		try {
			
			// 입력한 내용 데이터 베이스에 입력
			// 입력한 리뷰의 리뷰 번호 반환
			int reviewNo = videoReviewDao.insertReview(vr);
			
			// 성공 메시지 출력
			System.out.println(reviewNo + "번 리뷰가 등록되었습니다.");
			
		} catch (IOException e) {
			
			// 에러 메시지 출력
			System.out.println("리뷰를 등록할 수 없습니다.");
		}
	}
}