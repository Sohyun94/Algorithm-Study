package com.ssafy.fit.view;

import java.io.IOException;
import java.util.Scanner;

import com.ssafy.fit.model.User;
import com.ssafy.fit.model.dao.IUserManager;
import com.ssafy.fit.model.dao.UserManagerImpl;

public class SignUI {
	private static Scanner sc = new Scanner(System.in);
	private static SignUI instance = new SignUI();

	private IUserManager userDao = UserManagerImpl.getInstance();

	public static SignUI getInstance() {
		return instance;
	}

	private SignUI() {
	}

	// 회원가입 UI
	public void service() {
		System.out.println("--------------------");
		System.out.println("자바로 구현하는 SSAFIT");
		System.out.println("--------------------");
		while (true) {
			System.out.println("--------------------");
			System.out.println("1. 회원가입");
			System.out.println("2. 로그인");
			System.out.println("0. 이전으로");
			System.out.println("--------------------");
			System.out.print("메뉴를 선택하세요 : ");
			int sel = sc.nextInt();
			switch (sel) {
			case 1:
				sign(); // 회원가입
				LoginUI.getInstance().service(); // 로그인 화면으로 이동
				break;
			case 2:
				LoginUI.getInstance().service(); // 로그인 화면으로 이동
				break;
			case 0:
				return;
			default:
				System.out.println("입력이 잘못되었습니다.");
			}
		}
	}

	private void sign() {

		User newUser = new User();

		String id;

		while (true) {

			System.out.print("아이디를 입력하세요. : ");
			id = sc.next();

			// 아이디 중복조회
			if (userDao.searchId(id)) {
				System.out.println("이미 존재하는 아이디입니다.");
				System.out.println("다른 아이디를 입력하세요.");
				continue;
			}

			newUser.setId(id);

			break;

		}

		System.out.print("비밀번호를 입력하세요. : ");
		newUser.setPassword(sc.next());

		System.out.print("이름을 입력하세요. : ");
		newUser.setName(sc.next());

		System.out.print("이메일을 입력하세요. : ");
		newUser.setEmail(sc.next());

		// 입력한 정보 데이터 베이스로 전달
		try {
			userDao.insertUser(newUser);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// 가입한 아이디에 대한 회원정보 조회
		System.out.println(userDao.searchById(id));

	}

}
