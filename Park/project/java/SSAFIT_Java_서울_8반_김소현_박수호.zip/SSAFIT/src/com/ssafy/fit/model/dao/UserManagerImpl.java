package com.ssafy.fit.model.dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.ssafy.fit.model.User;

public class UserManagerImpl implements IUserManager {

	// 필드
	private List<User> userDb = new ArrayList<>();
	private boolean isLogin = false;
	private static UserManagerImpl instance = new UserManagerImpl();

	// singleton
	private UserManagerImpl() {
	}

	public static UserManagerImpl getInstance() {
		return instance;
	}

	// 회원정보 추가
	@Override
	public void insertUser(User user) throws IOException {

		// 파일 쓰기
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("data/user.json"), "utf-8"));

		// 데이터베이스에 새로운 회원정보 추가
		userDb.add(user);

		// Gson 객체 생성
		Gson gson = new Gson();

		// 데이터베이스 내용을 json으로 변환
		String jsonStr = gson.toJson(userDb);

		// 파일에 json 작성
		bw.write(jsonStr);

		// 종료
		bw.flush();
		bw.close();

	}

	// 회원정보 조회
	@Override
	public void loadUser() {

		StringBuilder sb = new StringBuilder();

		// 파일 읽기
		try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("data/user.json")))) {
			
			String str = null;
			
			while ((str = br.readLine()) != null) {
				sb.append(str).append("\n");
			}
			
			// 파일 내용
			String jsonStr = sb.toString();
			
			// Gson 객체 생성
			Gson gson = new Gson();
			
			// json 내용을 회원정보 배열로 변환
			User[] users = gson.fromJson(jsonStr, User[].class);
			
			// 배열 내용을 데이터 베이스에 복사
			for (int i = 0; i < users.length; i++) {
				userDb.add(users[i]);
			}
			
		} catch (FileNotFoundException e) {
			
			// 에러 메시지 출력
			String errorMsg = e.getMessage();
			System.out.println(errorMsg);
			
		} catch (IOException e) {
			
			// 에러 메시지 출력
			System.out.println("파일을 찾을 수 없습니다.");
			
		}

	}

	// 아이디 있는지 검사
	@Override
	public boolean searchId(String id) {

		// 존재 여부를 저장할 변수 선언
		boolean isExist = false;

		// 데이터 베이스에 해당 아이디가 있는지 확인하는 반복문
		for (int i = 0; i < userDb.size(); i++) {
			if (id.equals(userDb.get(i).getId())) {
				isExist = true; // 존재하면 true 반환
			}
		}

		// 존재여부 반환(있으면 true, 없으면 false)
		return isExist;
	}

	// 회원가입 결과 정보 반환
	// 로그인 후 가입 정보 출력
	@Override
	public User searchById(String id) {

		// User 객체 생성
		User user = new User();

		// 가입한 아이디에 대한 정보를 데이터 베이스에서 찾기
		for (int i = 0; i < userDb.size(); i++) {
			if (id.equals(userDb.get(i).getId())) {
				user = userDb.get(i); // 존재하면 해당 정보 반환
				break;
			}
		}

		// 가입 정보 반환
		return user;
	}

	// 로그인
	public boolean login(String id, String password) {

		// 데이터 베이스에 아이디와 비밀번호가 일치하는지 확인하는 반복문
		for (User user : userDb) {
			if (user.getId().equals(id) && user.getPassword().equals(password)) {
				isLogin = true; // 둘 다 일치하면 true 반환
				break;
			}
		}

		// 로그인 성공 여부 반환
		return isLogin;
	}

	// 로그아웃
	public void logOut() {
		
		// 로그아웃 버튼을 누르면 로그인 상태를 false로 반환
		isLogin = false;
	}
	
	// 로그인 상태
	public boolean isLogin() {
		
		// 현재 로그인 상태 반환
		return isLogin;
	}

}
