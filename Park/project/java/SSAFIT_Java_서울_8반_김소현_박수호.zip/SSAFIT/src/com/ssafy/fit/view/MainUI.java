package com.ssafy.fit.view;

import java.util.Scanner;

import com.ssafy.fit.model.dao.IUserManager;
import com.ssafy.fit.model.dao.UserManagerImpl;

public class MainUI {
	private static Scanner sc = new Scanner(System.in);
	private static MainUI instance = new MainUI();

	private static IUserManager userDao = UserManagerImpl.getInstance();

	public static MainUI getInstance() {
		userDao.loadUser();
		return instance;
	}

	private MainUI() {
	}

	// 메인 화면 UI
	public void service() {
		System.out.println("--------------------");
		System.out.println("자바로 구현하는 SSAFIT");
		System.out.println("--------------------");
		while (true) {
			System.out.println("--------------------");
			System.out.println("1. 영상정보");
			// 로그인 상태에 따라 메뉴 모습 다르게
			if (!userDao.isLogin()) {
				System.out.println("2. 로그인");
				System.out.println("3. 회원가입");
			} else {
				System.out.println("2. 로그아웃");
			}
			System.out.println("0. 종료");
			System.out.println("--------------------");
			System.out.print("메뉴를 선택하세요 : ");
			int sel = sc.nextInt();
			switch (sel) {
			case 1:
				VideoUI.getInstance().service(); // 영상 조회 화면으로 이동
				break;
			case 2:
				// 로그인 상태에 따라 해당 번호의 메뉴 선택 시 수행되는 기능 분류
				if (!userDao.isLogin()) {
					LoginUI.getInstance().service(); // 로그인 화면으로 이동
					break;
				} else {
					userDao.logOut(); // 로그아웃
					System.out.println("로그아웃 되었습니다."); // 로그아웃 메시지
					MainUI.getInstance().service(); // 메인 화면으로 복귀
				}

			case 3:
				// 로그인 상태에 따라 해당 번호의 메뉴 선택 시 수행되는 기능 분류
				if (!userDao.isLogin()) {
					SignUI.getInstance().service(); // 회원가입 화면으로 이동
					break;
				} else {
					System.out.println("잘못 입력하였습니다."); // 로그아웃 상태일 때 해당 번호 메뉴를 입력해도 아무 기능 실행 안함
					continue;
				}
			case 0:
				exit(); // 종료
			default:
				System.out.println("입력이 잘못되었습니다.");
			}
		}
	}

	private void exit() {
		System.out.println("--------------------");
		System.out.println("시스템을 종료합니다.");
		System.exit(0);
	}
}
