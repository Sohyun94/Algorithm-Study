package com.ssafy.fit.exception;

public class VideoNotFoundException extends Exception {

	// 해당 번호의 영상이 없을 경우 예외 처리
	public VideoNotFoundException(int no) {
		super(no + " 영상을 찾을 수 없습니다.");
	}
	
}
