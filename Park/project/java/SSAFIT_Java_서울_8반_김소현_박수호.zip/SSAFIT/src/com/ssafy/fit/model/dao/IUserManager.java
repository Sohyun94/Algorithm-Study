package com.ssafy.fit.model.dao;

import java.io.IOException;

import com.ssafy.fit.model.User;

public interface IUserManager {

	// 회원 등록
	public void insertUser(User user) throws IOException;

	// 데이터 불러오기
	public void loadUser();

	// 아이디 중복조회
	public boolean searchId(String id);

	// 가입한 정보 확인
	public User searchById(String id);
	
	// 로그인
	public boolean login(String id, String password);
	
	// 로그아웃
	public void logOut();
	
	// 로그인 상태
	public boolean isLogin();

}
