package com.ssafy.fit.model.dao;

import java.io.IOException;
import java.util.List;

import com.ssafy.fit.model.VideoReview;

public interface IVideoReviewDao {

	// 리뷰 등록 
	int insertReview(VideoReview videoReview) throws IOException;
	
	// 리뷰 목록 조회
	List<VideoReview> selectReview(int videoNo) throws IOException, ClassNotFoundException;
}
