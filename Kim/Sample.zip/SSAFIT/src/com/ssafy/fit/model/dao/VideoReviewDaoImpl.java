package com.ssafy.fit.model.dao;

//IVideoReviewDao를 상속받아 구현하세요.
// 추가기능 : json이나 ObjectStream을 이용해 파일에 리뷰들을 관리하는 기능
public class VideoReviewDaoImpl {

}
